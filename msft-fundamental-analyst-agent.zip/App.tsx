import React, { useState } from 'react';
import { 
  ArrowRight, 
  BarChart2, 
  BookOpen, 
  CheckCircle, 
  DollarSign, 
  PieChart, 
  RefreshCcw, 
  TrendingUp,
  FileText,
  Printer
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

import { UserInputs, AnalystContext } from './types';
import { 
  extract_capital_structure, 
  estimate_wacc, 
  compute_fcf_proxy, 
  run_scenarios_and_sensitivity, 
  build_context_json 
} from './services/analystTools';
import { generateMemo } from './services/geminiService';

// Helper to format currency
const formatUSD = (val: number, compact = true) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    notation: compact ? 'compact' : 'standard',
    maximumFractionDigits: 1
  }).format(val);
};

const formatPct = (val: number) => {
  return (val * 100).toFixed(2) + '%';
};

const App: React.FC = () => {
  const [step, setStep] = useState<'input' | 'processing' | 'results' | 'generating' | 'memo'>('input');
  
  // Default Inputs
  const [inputs, setInputs] = useState<UserInputs>({
    rf: 0.0425, // 4.25% default
    erp: 0.05,
    forecast_years: 5,
    fcf_growth: 0.05,
    terminal_g: 0.025,
    beta_override: null,
    kd_override: null,
  });

  const [context, setContext] = useState<AnalystContext | null>(null);
  const [memoContent, setMemoContent] = useState<string>('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({
      ...prev,
      [name]: parseFloat(value)
    }));
  };

  const handleRunAnalysis = async () => {
    setStep('processing');
    
    // Simulate API delay for realism
    setTimeout(() => {
      try {
        // 1. Extract Cap Struct
        const cs = extract_capital_structure();
        
        // 2. Estimate WACC
        const wacc = estimate_wacc(cs, inputs);
        
        // 3. Compute FCF
        const fcf = compute_fcf_proxy();
        
        // 4. Run Scenarios
        const sens = run_scenarios_and_sensitivity(
          fcf.fcf0_latest, 
          wacc.wacc, 
          inputs, 
          cs.net_debt, 
          cs.shares_outstanding
        );
        
        // 5. Build Context
        const ctx = build_context_json(inputs, cs, wacc, fcf, sens);
        
        setContext(ctx);
        setStep('results');
      } catch (err) {
        console.error(err);
        alert("Error running analysis");
        setStep('input');
      }
    }, 1500);
  };

  const handleGenerateMemo = async () => {
    if (!context) return;
    setStep('generating');
    const memo = await generateMemo(context);
    setMemoContent(memo);
    setStep('memo');
  };

  // Custom Markdown Components for polished document look
  const MarkdownComponents = {
    h1: ({node, ...props}: any) => <h1 className="text-3xl font-extrabold text-gray-900 mb-6 pb-4 border-b-2 border-gray-200" {...props} />,
    h2: ({node, ...props}: any) => <h2 className="text-xl font-bold text-blue-800 mt-8 mb-4 flex items-center gap-2 border-l-4 border-blue-600 pl-3" {...props} />,
    h3: ({node, ...props}: any) => <h3 className="text-lg font-semibold text-gray-800 mt-6 mb-2" {...props} />,
    p: ({node, ...props}: any) => <p className="text-gray-700 leading-relaxed mb-4 text-justify" {...props} />,
    ul: ({node, ...props}: any) => <ul className="list-disc pl-5 mb-4 space-y-2 text-gray-700 marker:text-blue-500" {...props} />,
    ol: ({node, ...props}: any) => <ol className="list-decimal pl-5 mb-4 space-y-2 text-gray-700 marker:text-blue-500" {...props} />,
    li: ({node, ...props}: any) => <li className="pl-1" {...props} />,
    strong: ({node, ...props}: any) => <strong className="font-bold text-gray-900" {...props} />,
    blockquote: ({node, ...props}: any) => <blockquote className="border-l-4 border-gray-300 pl-4 italic text-gray-600 my-4 bg-gray-50 p-4 rounded-r" {...props} />,
    // Enhanced Table Styling
    table: ({node, ...props}: any) => (
      <div className="overflow-x-auto my-6 rounded-lg border border-gray-200 shadow-sm">
        <table className="min-w-full divide-y divide-gray-200" {...props} />
      </div>
    ),
    thead: ({node, ...props}: any) => <thead className="bg-gray-100" {...props} />,
    th: ({node, ...props}: any) => <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider border-b border-gray-200" {...props} />,
    tbody: ({node, ...props}: any) => <tbody className="bg-white divide-y divide-gray-200" {...props} />,
    tr: ({node, ...props}: any) => <tr className="even:bg-gray-50 hover:bg-blue-50 transition-colors" {...props} />,
    td: ({node, ...props}: any) => <td className="px-4 py-3 text-sm text-gray-700 font-mono" {...props} />,
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <header className="mb-8 flex items-center justify-between border-b border-gray-700 pb-4">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="text-blue-500" />
              MSFT Analyst Agent
            </h1>
            <p className="text-sm text-gray-400 mt-1">
              Track A: Fundamental Analysis (FCFF DCF + WACC)
            </p>
          </div>
          <div className="text-xs text-gray-500 text-right">
             Source: Simulated yfinance
          </div>
        </header>

        {/* --- STEP 1: INPUTS --- */}
        {step === 'input' && (
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 shadow-lg animate-fade-in">
            <h2 className="text-xl font-semibold mb-4 text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Step A: Analyst Assumptions
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Required Inputs */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-blue-400 uppercase tracking-wider">Market Parameters</h3>
                <div>
                  <label className="block text-sm mb-1 text-gray-300">Risk-Free Rate (Rf)</label>
                  <input 
                    type="number" step="0.001" name="rf" value={inputs.rf} onChange={handleInputChange}
                    className="w-full bg-gray-900 border border-gray-600 rounded p-2 focus:border-blue-500 outline-none text-white"
                  />
                  <p className="text-xs text-gray-500 mt-1">Current 10Y Treasury Yield (decimal, e.g. 0.04)</p>
                </div>
                <div>
                  <label className="block text-sm mb-1 text-gray-300">Equity Risk Premium (ERP)</label>
                  <input 
                    type="number" step="0.001" name="erp" value={inputs.erp} onChange={handleInputChange}
                    className="w-full bg-gray-900 border border-gray-600 rounded p-2 focus:border-blue-500 outline-none text-white"
                  />
                  <p className="text-xs text-gray-500 mt-1">Recommended: 0.05 - 0.055</p>
                </div>
              </div>

              {/* DCF Inputs */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-purple-400 uppercase tracking-wider">DCF Inputs</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm mb-1 text-gray-300">Forecast Years</label>
                    <input 
                      type="number" name="forecast_years" value={inputs.forecast_years} onChange={handleInputChange}
                      className="w-full bg-gray-900 border border-gray-600 rounded p-2 focus:border-blue-500 outline-none text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-1 text-gray-300">FCF Growth (Stage 1)</label>
                    <input 
                      type="number" step="0.01" name="fcf_growth" value={inputs.fcf_growth} onChange={handleInputChange}
                      className="w-full bg-gray-900 border border-gray-600 rounded p-2 focus:border-blue-500 outline-none text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm mb-1 text-gray-300">Terminal Growth (g)</label>
                  <input 
                    type="number" step="0.001" name="terminal_g" value={inputs.terminal_g} onChange={handleInputChange}
                    className="w-full bg-gray-900 border border-gray-600 rounded p-2 focus:border-blue-500 outline-none text-white"
                  />
                  <p className="text-xs text-gray-500 mt-1">Must be &lt; WACC</p>
                </div>
              </div>
            </div>
            
            <div className="mt-8 flex justify-end">
              <button 
                onClick={handleRunAnalysis}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors flex items-center gap-2"
              >
                Fetch Data & Run Valuation
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* --- STEP 2: PROCESSING INDICATOR --- */}
        {step === 'processing' && (
          <div className="flex flex-col items-center justify-center py-20 animate-pulse">
            <RefreshCcw className="w-12 h-12 text-blue-500 animate-spin mb-4" />
            <p className="text-lg font-medium text-gray-300">Fetching yfinance bundle...</p>
            <p className="text-sm text-gray-500">Extracting Capital Structure & Estimating WACC</p>
          </div>
        )}

        {/* --- STEP 3: RESULTS DASHBOARD --- */}
        {step === 'results' && context && (
          <div className="space-y-6 animate-fade-in">
            {/* Top Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                <div className="flex items-center gap-2 mb-2 text-gray-400">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-sm font-semibold uppercase">Intrinsic Value / Share</span>
                </div>
                <div className="text-3xl font-bold text-white">
                  {formatUSD(context.valuation.value_per_share)}
                </div>
                <div className={`text-sm mt-1 ${context.valuation.upside_vs_spot! > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {context.valuation.upside_vs_spot! > 0 ? '+' : ''}{formatPct(context.valuation.upside_vs_spot!)} vs Spot
                </div>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                <div className="flex items-center gap-2 mb-2 text-gray-400">
                  <PieChart className="w-4 h-4" />
                  <span className="text-sm font-semibold uppercase">WACC</span>
                </div>
                <div className="text-3xl font-bold text-white">
                  {formatPct(context.wacc.wacc)}
                </div>
                <div className="text-xs text-gray-500 mt-1 flex justify-between">
                  <span>Ke: {formatPct(context.wacc.cost_of_equity_ke)}</span>
                  <span>Kd(at): {formatPct(context.wacc.cost_of_debt_kd * (1-context.wacc.tax_rate_effective))}</span>
                </div>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                <div className="flex items-center gap-2 mb-2 text-gray-400">
                  <BarChart2 className="w-4 h-4" />
                  <span className="text-sm font-semibold uppercase">Net Debt</span>
                </div>
                <div className="text-2xl font-bold text-white">
                  {formatUSD(context.capital_structure.net_debt, true)}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Cash: {formatUSD(context.capital_structure.cash_and_equivalents, true)}
                </div>
              </div>
            </div>

            {/* Detailed Tables Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Capital Structure Table */}
              <div className="bg-gray-800 p-5 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold text-white mb-4 border-b border-gray-700 pb-2">Capital Structure</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Equity Value (E)</span>
                    <span className="font-mono">{formatUSD(context.capital_structure.equity_market_value_E)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Book Debt (D)</span>
                    <span className="font-mono">{formatUSD(context.capital_structure.debt_book_value_D)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Weight Equity (wE)</span>
                    <span className="font-mono">{formatPct(context.wacc.weights.w_e)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Weight Debt (wD)</span>
                    <span className="font-mono">{formatPct(context.wacc.weights.w_d)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-gray-700">
                    <span className="text-gray-400">Tax Rate (Effective)</span>
                    <span className="font-mono">{formatPct(context.wacc.tax_rate_effective)}</span>
                  </div>
                </div>
              </div>

              {/* Sensitivity Grid */}
              <div className="bg-gray-800 p-5 rounded-lg border border-gray-700 overflow-x-auto">
                 <h3 className="text-lg font-semibold text-white mb-4 border-b border-gray-700 pb-2">Sensitivity (Price/Share)</h3>
                 <table className="w-full text-center text-xs">
                    <thead>
                      <tr>
                        <th className="p-1 text-gray-500">WACC \ g</th>
                        {context.sensitivity.sensitivity.g_values.map(g => (
                          <th key={g} className="p-1 font-mono text-blue-400">{formatPct(g)}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {context.sensitivity.sensitivity.wacc_values.map((w, i) => (
                        <tr key={w}>
                          <td className="p-1 font-mono text-purple-400 text-right pr-2">{formatPct(w)}</td>
                          {context.sensitivity.sensitivity.value_per_share_matrix[i].map((val, j) => (
                             <td key={`${i}-${j}`} className={`p-1 font-mono ${Math.abs(val - context.valuation.value_per_share) < 5 ? 'bg-gray-700' : ''}`}>
                               ${val.toFixed(0)}
                             </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                 </table>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <button 
                onClick={() => setStep('input')}
                className="text-gray-400 hover:text-white underline text-sm"
              >
                Back to Inputs
              </button>
              <button 
                onClick={handleGenerateMemo}
                className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors flex items-center gap-2"
              >
                <FileText className="w-4 h-4" />
                Write Investment Memo (Gemini)
              </button>
            </div>
          </div>
        )}

        {/* --- STEP 4: GENERATING MEMO --- */}
        {step === 'generating' && (
           <div className="flex flex-col items-center justify-center py-20 animate-pulse">
            <div className="relative">
              <FileText className="w-16 h-16 text-green-500 mb-4" />
              <div className="absolute top-0 right-0 w-4 h-4 bg-blue-500 rounded-full animate-ping"></div>
            </div>
            <p className="text-lg font-medium text-gray-300">Gemini is writing the memo...</p>
            <p className="text-sm text-gray-500 max-w-md text-center">
              Synthesizing context, analyzing capital structure weights, and structuring the DCF narrative.
            </p>
          </div>
        )}

        {/* --- STEP 5: FINAL MEMO --- */}
        {step === 'memo' && (
          <div className="animate-fade-in pb-12">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <CheckCircle className="w-6 h-6 text-green-500" />
                Investment Memo
              </h2>
              <div className="flex gap-4">
                <button 
                  onClick={() => window.print()}
                  className="text-sm text-gray-400 hover:text-white flex items-center gap-1"
                >
                  <Printer className="w-4 h-4" />
                  Print
                </button>
                <button 
                  onClick={() => setStep('results')}
                  className="text-sm text-blue-400 hover:text-blue-300"
                >
                  Edit Parameters
                </button>
              </div>
            </div>
            
            {/* Document Container */}
            <div className="bg-white text-gray-900 rounded-lg shadow-2xl overflow-hidden max-w-4xl mx-auto border border-gray-300">
               {/* Decorative top bar to simulate branded document */}
               <div className="h-2 bg-blue-600 w-full"></div>
               
               <article className="p-8 md:p-12">
                  <ReactMarkdown 
                    remarkPlugins={[remarkGfm]} 
                    components={MarkdownComponents}
                  >
                    {memoContent}
                  </ReactMarkdown>
               </article>

               {/* Footer for document feel */}
               <div className="bg-gray-50 border-t border-gray-200 p-4 text-center text-xs text-gray-500">
                 Generated by MSFT Analyst Agent &bull; {new Date().toLocaleDateString()} &bull; Private & Confidential
               </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default App;